******************
REST API Reference
******************

.. toctree::
   :maxdepth: 2

   rest_api/endpoint_specs
   rest_api/error_codes
   rest_api/state_delta_websockets

.. Licensed under Creative Commons Attribution 4.0 International License
.. https://creativecommons.org/licenses/by/4.0/
